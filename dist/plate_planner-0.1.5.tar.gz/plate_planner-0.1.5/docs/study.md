# Study Documentation
::: src.study
    handler: python
    