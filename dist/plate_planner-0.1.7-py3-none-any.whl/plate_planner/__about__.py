# SPDX-FileCopyrightText: 2023-present Filip (Persson) Ljung <filip.persson@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.1.7'
