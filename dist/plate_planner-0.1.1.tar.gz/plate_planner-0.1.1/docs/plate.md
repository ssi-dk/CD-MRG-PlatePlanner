# Plate Documentation
::: src.plate
    handler: python