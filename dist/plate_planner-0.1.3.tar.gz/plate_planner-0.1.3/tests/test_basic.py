import pytest

def test_read_configfile_plate():
    keys = ["rows", "columns",]
    # assert 
    pass

def test_read_configfile_QC():
    pass




